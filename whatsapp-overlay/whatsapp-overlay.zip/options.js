document.getElementById('apiKey').addEventListener('focus', async () => {
  const { claudeApiKey } = await chrome.storage.local.get('claudeApiKey');
  if (claudeApiKey) document.getElementById('apiKey').value = claudeApiKey;
});

document.getElementById('save').addEventListener('click', async () => {
  const key = document.getElementById('apiKey').value.trim();
  await chrome.storage.local.set({ claudeApiKey: key });
  const status = document.getElementById('status');
  status.textContent = 'Gespeichert.';
  setTimeout(() => (status.textContent = ''), 2000);
});
