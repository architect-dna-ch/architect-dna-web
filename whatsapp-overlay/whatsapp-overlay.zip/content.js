// WhatsApp Overlay Assistant — content script
// Reads visible chat text ONLY when the user clicks the toggle. No continuous
// scraping, no auto-send. Personal use only.

let panelOpen = false;

function createToggleButton() {
  const btn = document.createElement('div');
  btn.id = 'wa-overlay-toggle';
  btn.textContent = '✨';
  btn.title = 'Vorschlag holen (on-demand)';
  document.body.appendChild(btn);
  btn.addEventListener('click', handleToggleClick);
}

function createPanel() {
  const panel = document.createElement('div');
  panel.id = 'wa-overlay-panel';
  panel.innerHTML = `
    <div id="wa-overlay-header">
      <span>Vorschlag</span>
      <span id="wa-overlay-close">×</span>
    </div>
    <div id="wa-overlay-body">
      <div id="wa-overlay-status">Bereit.</div>
      <div id="wa-overlay-result"></div>
    </div>
  `;
  document.body.appendChild(panel);
  panel.style.display = 'none';
  document.getElementById('wa-overlay-close').addEventListener('click', () => {
    panel.style.display = 'none';
    panelOpen = false;
  });
  return panel;
}

function getVisibleMessages(n = 15) {
  // WhatsApp Web message bubbles — selector may need adjustment if WA updates their DOM.
  const nodes = document.querySelectorAll('[data-testid="msg-container"], .message-in, .message-out');
  const texts = [];
  nodes.forEach(node => {
    const t = node.innerText?.trim();
    if (t) texts.push(t);
  });
  return texts.slice(-n).join('\n');
}

async function handleToggleClick() {
  const panel = document.getElementById('wa-overlay-panel') || createPanel();
  panel.style.display = 'block';
  panelOpen = true;

  const status = document.getElementById('wa-overlay-status');
  const result = document.getElementById('wa-overlay-result');
  status.textContent = 'Lese sichtbaren Chat…';
  result.textContent = '';

  const context = getVisibleMessages();
  if (!context) {
    status.textContent = 'Kein Chat-Text gefunden. Öffne eine Konversation.';
    return;
  }

  const { claudeApiKey } = await chrome.storage.local.get('claudeApiKey');
  if (!claudeApiKey) {
    status.textContent = 'Kein API-Key hinterlegt. Erweiterungs-Icon anklicken zum Einrichten.';
    return;
  }

  status.textContent = 'Frage Claude…';
  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-api-key': claudeApiKey,
        'anthropic-version': '2023-06-01',
        'anthropic-dangerous-direct-browser-access': 'true'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-5',
        max_tokens: 400,
        messages: [{
          role: 'user',
          content: `Hier ist der letzte Chatverlauf (WhatsApp). Gib einen kurzen Ton-Hinweis (1 Satz) und einen konkreten Antwortvorschlag (max. 2 Sätze) auf Deutsch. Antworte NUR im Format:\nTON: ...\nVORSCHLAG: ...\n\n${context}`
        }]
      })
    });
    const data = await response.json();
    status.textContent = '';
    result.textContent = data?.content?.[0]?.text || 'Keine Antwort erhalten.';
  } catch (err) {
    status.textContent = 'Fehler: ' + err.message;
  }
}

createToggleButton();
